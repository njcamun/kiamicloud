import { Hono } from 'hono';
import type { Env } from '../types';
import { BLADE_CONSOLE_HTML } from '../blade-console/html';

/** Consola web local — apenas ambiente development (ZimaBlade). */
export const bladeConsoleRoutes = new Hono<{ Bindings: Env }>();

function isBladeConsoleEnabled(env: Env): boolean {
  return env.ENVIRONMENT === 'development';
}

bladeConsoleRoutes.get('/', (c) => {
  if (!isBladeConsoleEnabled(c.env)) {
    return c.text('Not found', 404);
  }
  return c.html(BLADE_CONSOLE_HTML);
});

bladeConsoleRoutes.get('/*', (c) => {
  if (!isBladeConsoleEnabled(c.env)) {
    return c.text('Not found', 404);
  }
  return c.html(BLADE_CONSOLE_HTML);
});
